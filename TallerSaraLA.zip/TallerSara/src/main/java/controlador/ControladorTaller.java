package controlador;

import dao.DAOFactory;
import dao.MySQLDAOFactory;
import dao.Interface.ClienteDAO;
import dao.Interface.UsuarioDAO;
import dao.Interface.VehiculoDAO;
import dao.Interface.ReparacionDAO;
import entities.Cliente;
import entities.Usuario;
import entities.Vehiculo;
import entities.Reparacion;
import entities.Estado;
import entities.Rol;
import java.util.ArrayList;
import java.util.List;

public class ControladorTaller {

	private static ControladorTaller instance;
	private Usuario usuarioActivo;
	private ClienteDAO clienteDAO;
	private UsuarioDAO usuarioDAO;
	private VehiculoDAO vehiculoDAO;
	private ReparacionDAO reparacionDAO;

	private DAOFactory factory;

	private ControladorTaller() {
		this.factory = new MySQLDAOFactory();

		this.clienteDAO = factory.getClienteDAO();
		this.usuarioDAO = factory.getUsuarioDAO();
		this.vehiculoDAO = factory.getVehiculoDAO();
		this.reparacionDAO = factory.getReparacionDAO();

		this.usuarioActivo = null;
	}

	public static ControladorTaller getInstance() {
		if (instance == null) {
			instance = new ControladorTaller();
		}
		return instance;
	}

	public Usuario login(String credencial, String password) {
		Usuario u = usuarioDAO.findByDniAndPassword(credencial, password);

		if (u != null) {
			this.usuarioActivo = u;
		}
		return u;
	}

	public void logout() { // esto es para cerrar la cuenta.
		this.usuarioActivo = null;
	}

	public boolean isAdmin() {
		return usuarioActivo != null && usuarioActivo.getRol().equals(Rol.ADMINISTRADOR);
	}

	public boolean isMecanico() {
		return isAdmin() || (usuarioActivo != null && usuarioActivo.getRol().equals(Rol.MECÁNICO));
	}

	// CU1: Ver reparaciones finalizadas (Público/Invitado)
	public List<Reparacion> listarReparacionesFinalizadas() {
		return reparacionDAO.findFinalizadas();
	}

	// CU3: Registrar nueva reparación
	public boolean insertarReparacion(Reparacion r) {
		if (!isMecanico()) {
			System.out.println("Acceso denegado. Se requiere ser Mecánico o Administrador.");
			return false;
		}

		if (r.getUsuario_id() == 0 && this.usuarioActivo != null) {
			r.setUsuario_id(this.usuarioActivo.getIdUsuario());
		}

		reparacionDAO.insert(r);
		return true;
	}

	// CU4: Cambiar estado de reparación (Mecánico / Admin)
	public boolean actualizarEstadoReparacion(int idReparacion, Estado nuevoEstado) {
		if (!isMecanico()) {
			System.out.println("❌ ERROR: Acceso denegado. Se requiere ser Mecánico o Administrador.");
			return false;
		}

		String estadoString = nuevoEstado.name().toUpperCase();
		reparacionDAO.updateEstado(idReparacion, estadoString);
		return true;
	}

	// Mecánico: Consultar sus reparaciones asignadas
	public ArrayList<Reparacion> verReparacionesMecanico() {
		if (!isMecanico()) {
			System.out.println("❌ ERROR: Acceso denegado. Se requiere ser Mecánico o Administrador.");
			return new ArrayList<>();
		}
		return reparacionDAO.findByMecanicoId(this.usuarioActivo.getIdUsuario(), null);
	}

	

	public boolean insertarCliente(Cliente c) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		clienteDAO.insert(c);
		return true;
	}

	public Cliente buscarClientePorDni(String dni) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return null;
		}
		return clienteDAO.findByDni(dni);
	}

	public ArrayList<Cliente> listarClientes() {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return new ArrayList<>();
		}
		return clienteDAO.findAll();
	}

	public boolean actualizarCliente(Cliente c) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		clienteDAO.update(c);
		return true;
	}

	public boolean eliminarCliente(String dni) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		clienteDAO.delete(dni);
		return true;
	}

	public boolean insertarVehiculo(Vehiculo v) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		vehiculoDAO.insert(v);
		return true;
	}

	public Vehiculo buscarVehiculoPorMatricula(String matricula) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return null;
		}
		return vehiculoDAO.findByMatricula(matricula);
	}

	public ArrayList<Vehiculo> listarVehiculos() {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return new ArrayList<>();
		}
		return vehiculoDAO.findall();
	}

	public boolean actualizarVehiculo(Vehiculo v) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		vehiculoDAO.update(v);
		return true;
	}

	public boolean eliminarVehiculo(String matricula) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		vehiculoDAO.delete(matricula);
		return true;
	}

	

	public boolean insertarUsuario(Usuario u) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		usuarioDAO.insert(u);
		return true;
	}

	public Usuario buscarUsuarioPorDni(String dni) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return null;
		}
		return usuarioDAO.findByDni(dni);
	}

	public ArrayList<Usuario> listarUsuarios() {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
		}
		return usuarioDAO.findall();
	}

	public boolean actualizarUsuario(Usuario u) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		usuarioDAO.update(u);
		return true;
	}

	public boolean eliminarUsuario(String dni) {
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return false;
		}
		usuarioDAO.delete(dni);
		return true;
	}

	
	public void verEstadisticas() { // este lo he tenido que buscar.
		if (!isAdmin()) {
			System.out.println("Acceso denegado. Se requiere ser Administrador.");
			return;
		}
		System.out.println("Estadísticas: Funcionalidad completa de cálculo pendiente de implementación en la capa DAO.");
	}
}