package dao.Interface;

import java.util.ArrayList;
import entities.Reparacion;

public interface ReparacionDAO {
	void insert(Reparacion r);
	void update(Reparacion r);
	void updateEstado(int idReparacion, String estado); 
	void delete(int idReparacion);
	void deleteByMatricula(String matricula);
	ArrayList<Reparacion> findByMatricula(String matricula);
	ArrayList<Reparacion> findFinalizadas();
	ArrayList<Reparacion> findByVehiculoId(int idVehiculo, Reparacion r);
	ArrayList<Reparacion> findByClienteId(int idCliente, Reparacion r);
	ArrayList<Reparacion> findByMecanicoId(int idUsuario, Reparacion r); 
}