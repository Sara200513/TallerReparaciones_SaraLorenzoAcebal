package dao.Interface;

import java.util.ArrayList;

import entities.Rol;
import entities.Usuario;

public interface UsuarioDAO {
	
	void update(Usuario u);
	void delete(String dni);
	Usuario findByDniAndPassword(String credencial, String password);
	void insert(Usuario u);
	ArrayList<Usuario> findall();
	Usuario findByNombre(String nombre);
	void updatePassword(String dni, String nuevaPassword); 
	ArrayList<Usuario> findByRol(Rol rol);
    Usuario findByDni(String dni); 
}