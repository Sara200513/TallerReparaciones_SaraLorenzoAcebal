package dao.Interface;

import java.util.ArrayList;

import entities.Vehiculo;

public interface VehiculoDAO {
	void insert(Vehiculo v);
	void update(Vehiculo v);
	void delete(String matricula);
	Vehiculo findByMatricula(String matricula);
	ArrayList<Vehiculo> findall();
	public Vehiculo findById(int idVehiculo);
	

}