package dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.DBConnection;
import dao.Interface.VehiculoDAO;
import entities.Vehiculo;

public class VehiculoDAOMySQL implements VehiculoDAO {

    private Connection conexion;

    public VehiculoDAOMySQL() {
        conexion = DBConnection.getInstance().getConnection();
    }

    @Override
    public void insert(Vehiculo v) {
        String sql = "INSERT INTO vehiculo (matricula, marca, modelo, cliente_id) VALUES (?, ?, ?, ?);";

        try (PreparedStatement pst = conexion.prepareStatement(sql)) {

            pst.setString(1, v.getMatricula());
            pst.setString(2, v.getMarca());
            pst.setString(3, v.getModelo());
            pst.setInt(4, v.getCliente_id());

            pst.executeUpdate();

        } catch (SQLException e) {
            System.out.println("> ERROR INSERT VEHICULO: " + e.getMessage());
        }
    }

    @Override
    public void update(Vehiculo v) {
        String sql = "UPDATE vehiculo SET matricula = ?, marca = ?, modelo = ? WHERE id_vehiculo = ?;";

        try (PreparedStatement pst = conexion.prepareStatement(sql)) {

            pst.setString(1, v.getMatricula());
            pst.setString(2, v.getMarca());
            pst.setString(3, v.getModelo());
            pst.setInt(4, v.getIdVehiculo());

            pst.executeUpdate();

        } catch (SQLException e) {
            System.out.println("> ERROR UPDATE VEHICULO: " + e.getMessage());
        }
    }

    @Override
    public void delete(String matricula) {
        String sql = "DELETE FROM vehiculo WHERE matricula = ?;";

        try (PreparedStatement pst = conexion.prepareStatement(sql)) {

            pst.setString(1, matricula);

            int filas = pst.executeUpdate();

            if (filas > 0)
                System.out.println("Vehículo con matrícula " + matricula + " eliminado correctamente.");
            else
                System.out.println("No existe ningún vehículo con matrícula " + matricula);

        } catch (SQLException e) {
            System.out.println("> ERROR DELETE VEHICULO: " + e.getMessage());
        }
    }

     @Override
    public Vehiculo findByMatricula(String matricula) {
        String sql = "SELECT id_vehiculo, matricula, marca, modelo, cliente_id "
                   + "FROM vehiculo WHERE matricula = ?;";

        try (PreparedStatement pst = conexion.prepareStatement(sql)) {

            pst.setString(1, matricula);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {
                    return new Vehiculo(
                        rs.getInt("id_vehiculo"),
                        rs.getString("matricula"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("cliente_id")
                    );
                }
            }

        } catch (SQLException e) {
            System.out.println("> ERROR FIND BY MATRICULA: " + e.getMessage());
        }

        return null;
    }

     @Override
    public ArrayList<Vehiculo> findall() {

        ArrayList<Vehiculo> lista = new ArrayList<>();
        String sql = "SELECT * FROM vehiculo;";

        try (PreparedStatement pst = conexion.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                Vehiculo v = new Vehiculo(
                    rs.getInt("id_vehiculo"),
                    rs.getString("matricula"),
                    rs.getString("marca"),
                    rs.getString("modelo"),
                    rs.getInt("cliente_id")
                );

                lista.add(v);
            }

        } catch (SQLException e) {
            System.out.println("> ERROR FIND ALL VEHICULOS: " + e.getMessage());
        }

        return lista;
    }

    @Override
    public Vehiculo findById(int idVehiculo) {

        String sql = "SELECT id_vehiculo, matricula, marca, modelo, cliente_id "
                   + "FROM vehiculo WHERE id_vehiculo = ?;";

        try (PreparedStatement pst = conexion.prepareStatement(sql)) {

            pst.setInt(1, idVehiculo);

            try (ResultSet rs = pst.executeQuery()) {

                if (rs.next()) {
                    return new Vehiculo(
                        rs.getInt("id_vehiculo"),
                        rs.getString("matricula"),
                        rs.getString("marca"),
                        rs.getString("modelo"),
                        rs.getInt("cliente_id")
                    );
                }
            }

        } catch (SQLException e) {
            System.out.println("> ERROR FIND BY ID VEHICULO: " + e.getMessage());
        }

        return null;
    }

}
