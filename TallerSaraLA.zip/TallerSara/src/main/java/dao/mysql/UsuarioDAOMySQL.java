package dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.DBConnection;
import dao.Interface.UsuarioDAO;
import entities.Rol;
import entities.Usuario;

public class UsuarioDAOMySQL implements UsuarioDAO {

	private Connection conexion;

	public UsuarioDAOMySQL() {
		this.conexion = DBConnection.getInstance().getConnection();
	}

	@Override
	public Usuario findByDniAndPassword(String credencial, String password) {

		String sql = "SELECT * FROM usuario WHERE (dni = ? OR nombre_usuario = ?) AND password = ?";

		try (PreparedStatement pst = conexion.prepareStatement(sql)) {

			pst.setString(1, credencial);
			pst.setString(2, credencial);
			pst.setString(3, password);
			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					return new Usuario(rs.getInt("id_usuario"), rs.getString("dni"), rs.getString("nombre_usuario"),
							rs.getString("password"), Rol.valueOf(rs.getString("rol").toUpperCase()));
				}
			}
		} catch (SQLException e) {
			System.out.println("> ERROR LOGIN: " + e.getMessage());
		}
		return null;
	}

	@Override
	public Usuario findByDni(String dni) {

		String sql = "SELECT * FROM usuario WHERE dni = ?";
		try (PreparedStatement pst = conexion.prepareStatement(sql)) {
			pst.setString(1, dni);
			try (ResultSet rs = pst.executeQuery()) {
				if (rs.next()) {
					return new Usuario(rs.getInt("id_usuario"), rs.getString("dni"), rs.getString("nombre_usuario"),
							rs.getString("password"), Rol.valueOf(rs.getString("rol").toUpperCase()));
				}
			}
		} catch (SQLException e) {
			System.out.println("> ERROR FIND BY DNI: " + e.getMessage());
		}
		return null;
	}

	@Override
	public void updatePassword(String dni, String nuevaPassword) {
		try {
			String sql = "UPDATE usuario SET password = ? WHERE dni = ?";
			try (PreparedStatement pst = conexion.prepareStatement(sql)) {
				pst.setString(1, nuevaPassword);
				pst.setString(2, dni);
				pst.executeUpdate();
			}
		} catch (SQLException e) {
			System.out.println("> ERROR UPDATE PASSWORD: " + e.getMessage());
		}
	}

	@Override
	public void insert(Usuario u) {
		try {
			String sql = "INSERT INTO usuario (dni, nombre_usuario, password, rol) VALUES (?, ?, ?, ?)";
			PreparedStatement pst = conexion.prepareStatement(sql);

			pst.setString(1, u.getDni());
			pst.setString(2, u.getNombreUsuario());
			pst.setString(3, u.getPassword());
			pst.setString(4, u.getRol().name());

			pst.executeUpdate();

		} catch (SQLException e) {
			System.out.println("> ERROR INSERT USUARIO: " + e.getMessage());
		}
	}

	@Override
	public ArrayList<Usuario> findall() {
		ArrayList<Usuario> lista = new ArrayList<>();

		try {
			String sql = "SELECT * FROM usuario";
			PreparedStatement pst = conexion.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();

			while (rs.next()) {

				Usuario u = new Usuario(rs.getInt("id_usuario"), rs.getString("dni"), rs.getString("nombre_usuario"),
						rs.getString("password"), Rol.valueOf(rs.getString("rol")));

				lista.add(u);
			}

		} catch (SQLException e) {
			System.out.println("> ERROR FINDALL USUARIO: " + e.getMessage());
		}

		return lista;
	}

	@Override
	public Usuario findByNombre(String nombre) {
		try {
			String sql = "SELECT * FROM usuario WHERE nombre_usuario = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);

			pst.setString(1, nombre);
			ResultSet rs = pst.executeQuery();

			if (rs.next()) {

				Usuario u = new Usuario(rs.getInt("id_usuario"), rs.getString("dni"), rs.getString("nombre_usuario"),
						rs.getString("password"), Rol.valueOf(rs.getString("rol")));

				return u;
			}

		} catch (SQLException e) {
			System.out.println("> ERROR FIND BY NOMBRE: " + e.getMessage());
		}

		return null;
	}

	@Override
	public void update(Usuario u) {
		try {
			String sql = "UPDATE usuario SET dni = ?, nombre_usuario = ?, password = ?, rol = ? "
					+ "WHERE id_usuario = ?";

			PreparedStatement pst = conexion.prepareStatement(sql);

			pst.setString(1, u.getDni());
			pst.setString(2, u.getNombreUsuario());
			pst.setString(3, u.getPassword());
			pst.setString(4, u.getRol().name());
			pst.setInt(5, u.getIdUsuario());

			pst.executeUpdate();

		} catch (SQLException e) {
			System.out.println("> ERROR UPDATE USUARIO: " + e.getMessage());
		}
	}

	@Override
	public void delete(String dni) {
		try {
			String sql = "DELETE FROM usuario WHERE dni = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);

			pst.setString(1, dni);

			int filas = pst.executeUpdate();

			if (filas > 0)
				System.out.println("Usuario con DNI " + dni + " eliminado correctamente.");
			else
				System.out.println("No existe un usuario con DNI " + dni);

		} catch (SQLException e) {
			System.out.println("> ERROR DELETE USUARIO: " + e.getMessage());
		}
	}

	@Override
	public ArrayList<Usuario> findByRol(Rol rol) {
		ArrayList<Usuario> lista = new ArrayList<>();

		try {
			String sql = "SELECT * FROM usuario WHERE rol = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setString(1, rol.name());

			ResultSet rs = pst.executeQuery();

			while (rs.next()) {
				Usuario u = new Usuario(rs.getInt("id_usuario"), rs.getString("dni"), rs.getString("nombre_usuario"),
						rs.getString("password"), rol);
				lista.add(u);
			}

		} catch (SQLException e) {
			System.out.println("> ERROR FIND BY ROL: " + e.getMessage());
		}

		return lista;
	}

}