package dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.ArrayList;

import dao.DBConnection;
import dao.Interface.ReparacionDAO;
import entities.Estado;
import entities.Reparacion;
import entities.Vehiculo;

public class ReparacionDAOMySQL implements ReparacionDAO {
	private Connection conexion;

	public ReparacionDAOMySQL() {
		conexion = DBConnection.getInstance().getConnection();
	}

	@Override
	public void insert(Reparacion r) {
		String sql = "INSERT INTO reparacion (descripcion, fechaEntrada, coste_estimado, estado, vehiculo_id, usuario_id) VALUES (?, ?, ?, ?, ?, ?)";
		try (PreparedStatement pst = conexion.prepareStatement(sql)) {
			pst.setString(1, r.getDescripcion());
			LocalDate fecha = r.getFechaEntrada();
			pst.setDate(2, java.sql.Date.valueOf(fecha));
			pst.setDouble(3, r.getCosteEstimado());
			pst.setString(4, r.getEstado().name());
			pst.setInt(5, r.getVehiculo_id());
			pst.setInt(6, r.getUsuario_id());

			int resul = pst.executeUpdate();
			System.out.println("Resultado de la insercion: " + resul);
		} catch (SQLException e) {
			System.out.println("> NOK: " + e.getMessage());
		}
	}

	@Override
	public void update(Reparacion r) {

		String sql = "UPDATE reparacion SET descripcion = ?, fechaEntrada = ?, coste_estimado = ?, estado = ?, vehiculo_id = ?, usuario_id = ? WHERE id_reparacion = ?";
		try (PreparedStatement pst = conexion.prepareStatement(sql)) {
			pst.setString(1, r.getDescripcion());
			LocalDate fecha = r.getFechaEntrada();
			pst.setDate(2, java.sql.Date.valueOf(fecha));
			pst.setDouble(3, r.getCosteEstimado());
			pst.setString(4, r.getEstado().name());
			pst.setInt(5, r.getVehiculo_id());
			pst.setInt(6, r.getUsuario_id());
			pst.setInt(7, r.getIdReparacion()); 

			int filas = pst.executeUpdate();
			if (filas > 0) {
				System.out.println("Reparación actualizada correctamente: " + filas);
			}
		} catch (SQLException e) {
			System.out.println("> NOK: " + e.getMessage());
		}
	}

	
	@Override
	public void updateEstado(int idReparacion, String estado) {
		try {
			String sql = "UPDATE reparacion SET estado = ? WHERE id_reparacion = ?";
			try (PreparedStatement pst = conexion.prepareStatement(sql)) {
				pst.setString(1, estado.toUpperCase()); 
				pst.setInt(2, idReparacion);

				pst.executeUpdate();
				System.out.println("Estado de reparación " + idReparacion + " actualizado a " + estado);
			}
		} catch (SQLException e) {
			System.out.println("> NOK update Estado: " + e.getMessage());
		}
	}

	
	@Override
	public ArrayList<Reparacion> findFinalizadas() {
        
        ArrayList<Reparacion> lista = new ArrayList<>();
		try {
			String sql = "SELECT * FROM reparacion WHERE estado = 'FINALIZADA' ORDER BY fechaEntrada DESC";
			PreparedStatement pst = conexion.prepareStatement(sql);
			ResultSet rs = pst.executeQuery();
			
			while (rs.next()) {
                
				Reparacion r = new Reparacion(
                    rs.getInt("id_reparacion"),
                    rs.getInt("vehiculo_id"),
                    rs.getInt("usuario_id"),
                    rs.getString("descripcion"),
                    rs.getDate("fechaEntrada").toLocalDate(),
                    rs.getDouble("coste_estimado"),
                    Estado.valueOf(rs.getString("estado"))
                );
				lista.add(r);
			}
		} catch (SQLException e) {
			System.out.println(" >NOK encontrada ninguna reparación finalizada: " + e.getMessage());
		}
		return lista;
	}

	@Override
	public void delete(int idReparacion) {
		try {
			String sql = "DELETE FROM reparacion WHERE id_reparacion = ?;";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, idReparacion);
			int filas = pst.executeUpdate();
			
			if (filas > 0) {
                System.out.println("Reparacion con id " + idReparacion + " eliminado correctamente");
            } else {
                System.out.println("Cliente con dni " + idReparacion + " no se encontró en la base de datos");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
 }

	@Override
	public void deleteByMatricula(String matricula) {

	    try {
	        VehiculoDAOMySQL vehiculoDAO = new VehiculoDAOMySQL();
	        Vehiculo v = vehiculoDAO.findByMatricula(matricula);

	        if (v == null) {
	            System.out.println("No existe vehículo con matrícula " + matricula);
	            return;
	        }

	        String sql = "DELETE FROM reparacion WHERE vehiculo_id = ?";

	        PreparedStatement pst = conexion.prepareStatement(sql);
	        pst.setInt(1, v.getIdVehiculo());

	        int filas = pst.executeUpdate();

	        System.out.println("Reparaciones eliminadas: " + filas);

	    } catch (SQLException e) {
	        System.out.println("> ERROR DELETE BY MATRICULA: " + e.getMessage());
	    }
 }

	@Override
	public ArrayList<Reparacion> findByMatricula(String matricula) {
		ArrayList<Reparacion> lista = new ArrayList<>();
		
	    try {
	        
	        VehiculoDAOMySQL vehiculoDAO = new VehiculoDAOMySQL();
	        Vehiculo v = vehiculoDAO.findByMatricula(matricula);

	        if (v == null) {
	            System.out.println("No existe vehículo con esa matrícula.");
	            return null;
	        }

	        
	        String sql = "SELECT * FROM reparacion WHERE vehiculo_id = ?";

	        PreparedStatement pst = conexion.prepareStatement(sql);
	        pst.setInt(1, v.getIdVehiculo());

	        try (ResultSet rs =pst.executeQuery()){
				while (rs.next()) {
					Reparacion rep = new Reparacion();
					rep.setIdReparacion(rs.getInt("id_reparacion"));
                    rep.setDescripcion(rs.getString("descripcion"));
                    rep.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
                    rep.setCosteEstimado(rs.getDouble("coste_estimado"));
                    rep.setEstado(Estado.valueOf(rs.getString("estado")));
                    rep.setVehiculo_id(rs.getInt("vehiculo_id"));
                    rep.setUsuario_id(rs.getInt("usuario_id"));
                    
                    lista.add(rep);
				}
	    
	        }
	    } catch (SQLException e) {
	        System.out.println("> ERROR FIND BY MATRICULA: " + e.getMessage());
	    }
	         return lista;

	}

	@Override
	public ArrayList<Reparacion> findByVehiculoId(int idVehiculo, Reparacion r) {
		ArrayList<Reparacion> lista = new ArrayList<>();
		try {
			String sql = "SELECT * FROM reparacion WHERE vehiculo_id = ?";
			PreparedStatement pst = conexion.prepareStatement(sql);
			pst.setInt(1, r.getVehiculo_id());
							
			try (ResultSet rs =pst.executeQuery()){
				while (rs.next()) {
					Reparacion rep = new Reparacion();
					rep.setIdReparacion(rs.getInt("id_reparacion"));
                    rep.setDescripcion(rs.getString("descripcion"));
                    rep.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
                    rep.setCosteEstimado(rs.getDouble("coste_estimado"));
                    rep.setEstado(Estado.valueOf(rs.getString("estado")));
                    rep.setVehiculo_id(rs.getInt("vehiculo_id"));
                    rep.setUsuario_id(rs.getInt("usuario_id"));
                    
                    lista.add(rep);
				}
			}
				
		} catch (SQLException e) {
			System.out.println(">NOK encontrado vehiculo: " + e.getMessage());
		}
		return lista;

	}

	@Override
	public ArrayList<Reparacion> findByClienteId(int idCliente, Reparacion r) {
		ArrayList<Reparacion> lista = new ArrayList<>();

	    try {
	        
	        VehiculoDAOMySQL vehiculoDAO = new VehiculoDAOMySQL();
	        Vehiculo v = vehiculoDAO.findById(r.getVehiculo_id()); 
	        if (v == null) return lista;

	        int idCliente1 = v.getCliente_id();

	        String sql = "SELECT rep.* FROM reparacion rep "
	                   + "JOIN vehiculo v ON rep.vehiculo_id = v.id_vehiculo "
	                   + "WHERE v.cliente_id = ?";

	        PreparedStatement pst = conexion.prepareStatement(sql);
	        pst.setInt(1, idCliente1);

	        ResultSet rs = pst.executeQuery();

	        while (rs.next()) {
	            Reparacion rep = new Reparacion();
	            rep.setIdReparacion(rs.getInt("id_reparacion"));
	            rep.setDescripcion(rs.getString("descripcion"));
	            rep.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
	            rep.setCosteEstimado(rs.getDouble("coste_estimado"));
	            rep.setEstado(Estado.valueOf(rs.getString("estado")));
	            rep.setVehiculo_id(rs.getInt("vehiculo_id"));
	            rep.setUsuario_id(rs.getInt("usuario_id"));

	            lista.add(rep);
	        }

	    } catch (SQLException e) {
	        System.out.println("> ERROR FIND BY CLIENTE: " + e.getMessage());
	    }

	    return lista;
	}


	@Override
	public ArrayList<Reparacion> findByMecanicoId(int idUsuario, Reparacion r) {
		ArrayList<Reparacion> lista = new ArrayList<>();
		try {
			String sql = "SELECT * FROM reparacion WHERE usuario_id = ?";

        
			PreparedStatement pst = conexion.prepareStatement(sql);
            pst.setInt(1, r.getUsuario_id());

            try (ResultSet rs = pst.executeQuery()) {

                while (rs.next()) {

                    Reparacion rep = new Reparacion();
                    rep.setIdReparacion(rs.getInt("id_reparacion"));
                    rep.setDescripcion(rs.getString("descripcion"));
                    rep.setFechaEntrada(rs.getDate("fechaEntrada").toLocalDate());
                    rep.setCosteEstimado(rs.getDouble("coste_estimado"));
                    rep.setEstado(Estado.valueOf(rs.getString("estado")));
                    rep.setVehiculo_id(rs.getInt("vehiculo_id"));
                    rep.setUsuario_id(rs.getInt("usuario_id"));

                    lista.add(rep);
                }
            }

        } catch (SQLException e) {
            System.out.println("> NOK FIND MECANICO: " + e.getMessage());
        }

        return lista;
        

	}
}