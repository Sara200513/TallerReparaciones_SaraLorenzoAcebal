package dao.mysql;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import dao.DBConnection;
import dao.Interface.ClienteDAO;
import entities.Cliente;

public class ClienteDAOMySQL implements ClienteDAO {
    private Connection conexion;

    public ClienteDAOMySQL() {
        conexion = DBConnection.getInstance().getConnection();
    }

    @Override
    public void insert(Cliente c) {
        String sql = "INSERT INTO cliente (dni, nombre, telefono, email) VALUES(?, ?, ?, ?)";
        try (PreparedStatement pst = conexion.prepareStatement(sql)) {
            pst.setString(1, c.getDni());
            pst.setString(2, c.getNombre());
            pst.setString(3, c.getTelefono());
            pst.setString(4, c.getEmail());

            int resul = pst.executeUpdate();
            System.out.println("Resultado de inserción: " + resul);
        } catch (SQLException e) {
            System.out.println("> NOK : " + e.getMessage());
        }
    }

    @Override
    public void update(Cliente c) {
        String sql = "UPDATE cliente SET dni = ?, nombre = ?, telefono = ?, email = ? WHERE id_cliente = ?";
        try (PreparedStatement pst = conexion.prepareStatement(sql)) {
            pst.setString(1, c.getDni());
            pst.setString(2, c.getNombre());
            pst.setString(3, c.getTelefono());
            pst.setString(4, c.getEmail());
            pst.setInt(5, c.getIdCliente());

            int filas = pst.executeUpdate();
            if (filas > 0)
                System.out.println("Cliente actualizado correctamente");
            else
                System.out.println("No se encontró el cliente para actualizar");
        } catch (SQLException e) {
            System.out.println("> NOK: " + e.getMessage());
        }
    }

    @Override
    public void delete(String dni) {
        String sqlDelete = "DELETE FROM cliente WHERE dni = ?";
        try (PreparedStatement pst = conexion.prepareStatement(sqlDelete)) {
            pst.setString(1, dni);
            int filas = pst.executeUpdate();
            if (filas > 0) {
                System.out.println("Cliente con dni " + dni + " eliminado correctamente");
            } else {
                System.out.println("Cliente con dni " + dni + " no se encontró en la base de datos");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public ArrayList<Cliente> findAll() {
        ArrayList<Cliente> clientes = new ArrayList<>();
        String sql = "SELECT dni, nombre, telefono, email FROM cliente";
        try (PreparedStatement pst = conexion.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {
            while (rs.next()) {
                Cliente c = new Cliente(
                        rs.getString("dni"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("email")
                );
                clientes.add(c);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return clientes;
    }

    @Override
    public Cliente findByDni(String dni) {
        String sql = "SELECT id_cliente, dni, nombre, telefono, email FROM cliente WHERE dni = ?";
        try (PreparedStatement pst = conexion.prepareStatement(sql)) {
            pst.setString(1, dni);
            ResultSet rs = pst.executeQuery();
            if (rs.next()) {
                return new Cliente(
                        rs.getInt("id_cliente"),
                        rs.getString("dni"),
                        rs.getString("nombre"),
                        rs.getString("telefono"),
                        rs.getString("email")
                );
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
