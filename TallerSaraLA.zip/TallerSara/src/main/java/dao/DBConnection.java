package dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

import com.mysql.cj.jdbc.MysqlDataSource;

public class DBConnection {

	private static DBConnection instance;
	private Connection conexionMySQL = null;

	private DBConnection() {
		try (InputStream in = DBConnection.class.getClassLoader().getResourceAsStream("conexion.properties")) {
			Properties props = new Properties();
			if (in == null) {
			    throw new IOException("conexion.properties no encontrado en resources");
			}
			props.load(in);

			MysqlDataSource ds = new MysqlDataSource();
			ds.setURL(props.getProperty("url"));
			ds.setUser(props.getProperty("user"));
			ds.setPassword(props.getProperty("password"));

			this.conexionMySQL = ds.getConnection();

		} catch (IOException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static DBConnection getInstance() {
		if (instance == null) {
			instance = new DBConnection();
		}
		return instance;
	}

	public Connection getConnection() {
		return conexionMySQL;
	}
}