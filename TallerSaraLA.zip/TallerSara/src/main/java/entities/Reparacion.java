package entities;

import java.time.LocalDate;

public class Reparacion {
	private int idReparacion;
	private int vehiculo_id;
	private int usuario_id; 
	private String descripcion;
	private LocalDate fechaEntrada;
	private Double costeEstimado;
	private Estado estado;

	public Reparacion() {
	}

	public Reparacion(int idReparacion, int vehiculo_id, int usuario_id, String descripcion, LocalDate fechaEntrada,
			Double costeEstimado, Estado estado) {
		this.idReparacion = idReparacion;
		this.vehiculo_id = vehiculo_id;
		this.usuario_id = usuario_id;
		this.descripcion = descripcion;
		this.fechaEntrada = fechaEntrada;
		this.costeEstimado = costeEstimado;
		this.estado = estado;
	}

	public int getIdReparacion() {
		return idReparacion;
	}

	public int getVehiculo_id() {
		return vehiculo_id;
	}

	public int getUsuario_id() {
		return usuario_id;
	}

	public String getDescripcion() {
		return descripcion;
	}

	public LocalDate getFechaEntrada() {
		return fechaEntrada;
	}

	public Double getCosteEstimado() {
		return costeEstimado;
	}

	public Estado getEstado() {
		return estado;
	}

	// Setters
	public void setIdReparacion(int idReparacion) {
		this.idReparacion = idReparacion;
	}

	public void setVehiculo_id(int vehiculo_id) {
		this.vehiculo_id = vehiculo_id;
	}

	public void setUsuario_id(int usuario_id) {
		this.usuario_id = usuario_id;
	}

	public void setDescripcion(String descripcion) {
		this.descripcion = descripcion;
	}

	public void setFechaEntrada(LocalDate fechaEntrada) {
		this.fechaEntrada = fechaEntrada;
	}

	public void setCosteEstimado(Double costeEstimado) {
		this.costeEstimado = costeEstimado;
	}

	public void setEstado(Estado estado) {
		this.estado = estado;
	}

//	@Override
//	public String toString() {
//		return String.format("%-5d | %-10d | %-40s | %-15s | %.2f € | %s", idReparacion, vehiculo_id, descripcion,
//				fechaEntrada, costeEstimado, estado);
//	}
}

