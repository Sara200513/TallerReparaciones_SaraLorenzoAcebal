package entities;

public class Usuario {
	private int idUsuario;
	private String dni;
	private String nombreUsuario;
	private String password;
	private Rol rol;

	public Usuario(int idUsuario, String dni, String nombreUsuario, String password, Rol rol) {
		this.idUsuario = idUsuario;
		this.dni = dni;
		this.nombreUsuario = nombreUsuario;
		this.password = password;
		this.rol = rol;
	}

	public Usuario(String dni, String nombreUsuario, String password, Rol rol) {
		this.dni = dni;
		this.nombreUsuario = nombreUsuario;
		this.password = password;
		this.rol = rol;
	}

	public int getIdUsuario() {
		return idUsuario;
	}

	public String getDni() {
		return dni;
	}

	public String getNombreUsuario() {
		return nombreUsuario;
	}

	public String getPassword() {
		return password;
	}

	public Rol getRol() {
		return rol;
	}

	public String getRolName() {
		return rol.name().toLowerCase();
	}

	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}

	public void setDni(String dni) {
		this.dni = dni;
	}

	public void setNombreUsuario(String nombreUsuario) {
		this.nombreUsuario = nombreUsuario;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRol(Rol rol) {
		this.rol = rol;
	}

	@Override
	public String toString() {
		return "Usuario [id=" + idUsuario + ", DNI=" + dni + ", Nombre=" + nombreUsuario + ", Rol=" + rol + "]";
	}
}