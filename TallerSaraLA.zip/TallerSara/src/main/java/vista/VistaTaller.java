package vista;

import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;

import controlador.ControladorTaller;
import entities.Estado;
import entities.Reparacion;
import entities.Usuario;

public class VistaTaller {

	private Scanner sc;
	private ControladorTaller controlador;

	public VistaTaller() {
		sc = new Scanner(System.in);

		controlador = ControladorTaller.getInstance();
	}

	public static void main(String[] args) {
		VistaTaller vista = new VistaTaller();
		vista.run();
	}

	public void run() {
		boolean salir = false;

		while (!salir) {
			mostrarMenuInvitado();
			int opcion = leerInt("Selecciona una opción: ");

			switch (opcion) {
			case 1:
				mostrarReparacionesFinalizadas();
				break;
			case 2:
				login();
				break;
			case 0:
				salir = true;
				System.out.println("Saliendo del sistema...");
				break;
			default:
				System.out.println("Opción no válida.");
			}
		}
	}

	private void mostrarMenuInvitado() {
		System.out.println("\n TALLER MECÁNICO");
		System.out.println("1. Ver reparaciones finalizadas");
		System.out.println("2. Login");
		System.out.println("0. Salir del programa");
	}

	private void mostrarReparacionesFinalizadas() {
		System.out.println("\n LISTADO DE REPARACIONES FINALIZADAS");
		List<Reparacion> lista = controlador.listarReparacionesFinalizadas();

		if (lista == null || lista.isEmpty()) {
			System.out.println("No hay reparaciones finalizadas.");
		} else {
			System.out.printf("ID", "VEH. ID", "DESCRIPCIÓN", "FECHA ENTRADA", "COSTE EST.");
			lista.forEach(System.out::println);
		}
	}

	private void login() {
		System.out.print("\nUsuario DNI o Nombre: ");
		String credencial = sc.nextLine();
		System.out.print("Contraseña: ");
		String password = sc.nextLine();

		Usuario u = controlador.login(credencial, password);

		if (u == null) {
			System.out.println("Las credenciales son incorrectas.");
		} else {
			System.out.println("Login correcto. Rol: " + u.getRolName());
			mostrarMenuPorRol(u);
		}
	}

	// menus por rol

	private void mostrarMenuPorRol(Usuario u) {
		switch (u.getRol().name().toLowerCase()) {
		case "mecanico":
			menuMecanico(u);
			break;
		case "administrador":
			menuAdmin(u);
			break;
		default:
			System.out.println("Rol no encontrado");
			controlador.logout();
		}
	}

	private void menuMecanico(Usuario u) {
		boolean sesionActiva = true;
		while (sesionActiva) {
			System.out.println("\n MENÚ MECÁNICO (" + u.getNombreUsuario() + ")");
			System.out.println("1. Registrar nueva reparación");
			System.out.println("2. Cambiar estado de reparación");
			System.out.println("3. Ver mis reparaciones");
			System.out.println("0. Cerrar sesión");

			int opcion = leerInt("Opción: ");

			switch (opcion) {
			case 1:
				Reparacion nuevaReparacion = leerDatosReparacion();
				if (controlador.insertarReparacion(nuevaReparacion)) {
					System.out.println("Reparación registrada correctamente. Asignada a ID: " + u.getIdUsuario());
				} else {
					System.out.println("No se pudo registrar la reparación.");
				}
				break;
			case 2:
				int idRep = leerInt("ID Reparación a cambiar estado: ");
				Estado nuevoEstado = leerNuevoEstado();
				if (controlador.actualizarEstadoReparacion(idRep, nuevoEstado)) {
					System.out.println("Estado de la reparación " + idRep + " actualizado a " + nuevoEstado.name());
				} else {
					System.out.println("No se pudo cambiar el estado de la reparación.");
				}
				break;
			case 3:
				System.out.println("\n MIS REPARACIONES ASIGNADAS");
				List<Reparacion> misReparaciones = controlador.verReparacionesMecanico();
				if (misReparaciones.isEmpty()) {
					System.out.println("No tienes reparaciones asignadas.");
				} else {
					misReparaciones.forEach(System.out::println);
				}
				break;
			case 0:
				controlador.logout();
				sesionActiva = false;
				System.out.println("Sesión cerrada. Volviendo al Menú Invitado.");
				break;
			default:
				System.out.println("Opción no válida");
			}
		}
	}

	private void menuAdmin(Usuario u) {
		boolean sesionActiva = true;
		while (sesionActiva) {
			System.out.println("\n MENÚ ADMINISTRADOR (" + u.getNombreUsuario() + ")");
			System.out.println("1. Gestión de clientes");
			System.out.println("2. Gestión de vehículos");
			System.out.println("3. Ver estadísticas");
			System.out.println("0. Cerrar sesión");

			int opcion = leerInt("Opción: ");

			switch (opcion) {
			case 1:
				System.out.println("\n LISTADO DE CLIENTES");
				controlador.listarClientes().forEach(System.out::println);
				break;
			case 2:
				System.out.println("\n LISTADO DE VEHÍCULOS ");
				controlador.listarVehiculos().forEach(System.out::println);
				break;
			case 3:
				controlador.verEstadisticas();
				break;
			case 0:
				controlador.logout();
				sesionActiva = false;
				System.out.println("Sesión cerrada. Volviendo al Menú Invitado.");
				break;
			default:
				System.out.println("Opción no válida");
			}
		}
	}

	private Reparacion leerDatosReparacion() {
		System.out.println("\n REGISTRAR NUEVA REPARACIÓN");

		int vehiculoId = leerInt("ID del Vehículo: ");

		System.out.print("Descripción de la avería: ");
		String descripcion = sc.nextLine();

		System.out.print("Fecha de entrada (YYYY-MM-DD, o dejar en blanco para hoy): ");
		String fechaStr = sc.nextLine();

		LocalDate fechaEntrada = LocalDate.now();
		if (!fechaStr.isEmpty()) {
			try {
				fechaEntrada = LocalDate.parse(fechaStr);
			} catch (Exception e) {
				System.out.println("Formato de fecha incorrecto. Se usará la fecha de hoy.");
			}
		}

		double coste = leerDouble("Coste Estimado (€): ");

		Reparacion r = new Reparacion();
		r.setVehiculo_id(vehiculoId);
		r.setDescripcion(descripcion);
		r.setFechaEntrada(fechaEntrada);
		r.setCosteEstimado(coste);
		r.setEstado(Estado.PENDIENTE); 
		r.setUsuario_id(0); 

		return r;
	}

	Estado leerNuevoEstado() {
		System.out.println("\n Selecciona el nuevo estado:");
		int i = 1;
		Estado[] estados = Estado.values();
		for (Estado estado : estados) {
			System.out.println(i++ + ". " + estado.name());
		}

		int opcion = leerInt("Opción: ");
		if (opcion > 0 && opcion <= estados.length) {
			return estados[opcion - 1];
		} else {
			System.out.println("Opción de estado no válida. Usando PENDIENTE.");
			return Estado.PENDIENTE;
		}
	}

	
	int leerInt(String msg) {
		System.out.print(msg);
		while (!sc.hasNextInt()) {
			System.out.println("Debe introducir un número entero válido.");
			sc.next();
		}
		int num = sc.nextInt();
		sc.nextLine(); 
		return num;
	}

	
	double leerDouble(String msg) {
		System.out.print(msg);
		while (!sc.hasNextDouble()) {
			System.out.println("Debe introducir un número decimal válido.");
			sc.next();
		}
		double num = sc.nextDouble();
		sc.nextLine(); 
		return num;
	}
}