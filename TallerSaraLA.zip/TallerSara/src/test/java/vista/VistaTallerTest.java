package vista;

import controlador.ControladorTaller;
import entities.Estado;
import org.junit.jupiter.api.*;

import java.io.*;
import java.nio.charset.StandardCharsets;

import static org.junit.jupiter.api.Assertions.*;

class VistaTallerTest {

    private ByteArrayInputStream testIn;
    private ByteArrayOutputStream testOut;
    private VistaTaller vista;

    @BeforeEach
    void setUp() {
        testOut = new ByteArrayOutputStream();
        System.setOut(new PrintStream(testOut));

        vista = new VistaTaller();
    }

    @AfterEach
    void tearDown() {
        System.setIn(System.in);
        System.setOut(System.out);
    }

    private void provideInput(String data) {
        testIn = new ByteArrayInputStream(data.getBytes(StandardCharsets.UTF_8));
        System.setIn(testIn);
    }

    private String getOutput() {
        return testOut.toString();
    }

    @Test
    void testLeerIntValido() {
        provideInput("5\n");
        int result = vista.leerInt("Introduce un número: ");
        assertEquals(5, result);
        assertTrue(getOutput().contains("Introduce un número"));
    }

    @Test
    void testLeerIntInvalido() {
        provideInput("abc\n7\n");
        int result = vista.leerInt("Introduce un número: ");
        assertEquals(7, result);
        assertTrue(getOutput().contains("Debe introducir un número entero válido."));
    }

    @Test
    void testLeerDoubleValido() {
        provideInput("12.5\n");
        double result = vista.leerDouble("Introduce un decimal: ");
        assertEquals(12.5, result);
        assertTrue(getOutput().contains("Introduce un decimal"));
    }

    @Test
    void testLeerDoubleInvalido() {
        provideInput("xyz\n9.75\n");
        double result = vista.leerDouble("Introduce un decimal: ");
        assertEquals(9.75, result);
        assertTrue(getOutput().contains("Debe introducir un número decimal válido."));
    }

    @Test
    void testLeerNuevoEstadoValido() {
        provideInput("2\n"); 
        Estado estado = vista.leerNuevoEstado();
        assertNotNull(estado);
        assertEquals(Estado.values()[1], estado);
    }

    @Test
    void testLeerNuevoEstadoInvalido() {
        provideInput("99\n"); 
        Estado estado = vista.leerNuevoEstado();
        assertEquals(Estado.PENDIENTE, estado);
        assertTrue(getOutput().contains("Opción de estado no válida"));
    }

}
