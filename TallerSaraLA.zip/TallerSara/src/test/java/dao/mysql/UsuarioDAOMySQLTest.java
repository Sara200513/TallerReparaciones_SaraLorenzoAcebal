package dao.mysql;

import entities.Rol;
import entities.Usuario;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class UsuarioDAOMySQLTest {

    private UsuarioDAOMySQL usuarioDAO;

    @BeforeEach
    void setUp() {
        usuarioDAO = new UsuarioDAOMySQL();
    }

    @Test
    void testInsert() {
        Usuario u = new Usuario(0, "11111111A", "testUser", "1234", Rol.ADMINISTRADOR);
        usuarioDAO.insert(u);

        Usuario encontrado = usuarioDAO.findByDni("11111111A");
        assertNotNull(encontrado);
        assertEquals("testUser", encontrado.getNombreUsuario());
    }

    @Test
    void testFindByDniAndPassword() {
        Usuario u = usuarioDAO.findByDniAndPassword("11111111A", "1234");
        assertNotNull(u);
        assertEquals("11111111A", u.getDni());
    }

    @Test
    void testFindByDni() {
        Usuario u = usuarioDAO.findByDni("11111111A");
        assertNotNull(u);
        assertEquals("11111111A", u.getDni());
    }

    @Test
    void testUpdatePassword() {
        usuarioDAO.updatePassword("11111111A", "nuevaClave");

        Usuario u = usuarioDAO.findByDniAndPassword("11111111A", "nuevaClave");
        assertNotNull(u);
        assertEquals("nuevaClave", u.getPassword());
    }

    @Test
    void testFindAll() {
        ArrayList<Usuario> lista = usuarioDAO.findall();
        assertNotNull(lista);
        assertTrue(lista.size() > 0);
    }

    @Test
    void testFindByNombre() {
        Usuario u = usuarioDAO.findByNombre("testUser");
        assertNotNull(u);
        assertEquals("testUser", u.getNombreUsuario());
    }

    @Test
    void testUpdate() {
        Usuario u = usuarioDAO.findByDni("11111111A");
        assertNotNull(u);

        u.setNombreUsuario("updatedUser");
        usuarioDAO.update(u);

        Usuario actualizado = usuarioDAO.findByNombre("updatedUser");
        assertNotNull(actualizado);
        assertEquals("updatedUser", actualizado.getNombreUsuario());
    }

    @Test
    void testDelete() {
        usuarioDAO.delete("11111111A");

        Usuario u = usuarioDAO.findByDni("11111111A");
        assertNull(u);
    }
}
