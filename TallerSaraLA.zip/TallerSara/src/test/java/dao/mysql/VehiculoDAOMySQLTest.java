package dao.mysql;

import entities.Vehiculo;
import org.junit.jupiter.api.*;

import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class VehiculoDAOMySQLTest {

    private VehiculoDAOMySQL vehiculoDAO;

    @BeforeEach
    void setUp() {
        vehiculoDAO = new VehiculoDAOMySQL();
    }

    @Test
    void testInsert() {
        Vehiculo v = new Vehiculo(0, "TEST123", "Toyota", "Corolla", 1); 
        vehiculoDAO.insert(v);

        Vehiculo encontrado = vehiculoDAO.findByMatricula("TEST123");
        assertNotNull(encontrado);
        assertEquals("Toyota", encontrado.getMarca());
    }

    @Test
    void testUpdate() {
        Vehiculo v = vehiculoDAO.findByMatricula("TEST123");
        assertNotNull(v);

        v.setMarca("Honda");
        v.setModelo("Civic");
        vehiculoDAO.update(v);

        Vehiculo actualizado = vehiculoDAO.findById(v.getIdVehiculo());
        assertEquals("Honda", actualizado.getMarca());
        assertEquals("Civic", actualizado.getModelo());
    }

    @Test
    void testFindByMatricula() {
        Vehiculo v = vehiculoDAO.findByMatricula("TEST123");
        assertNotNull(v);
        assertEquals("TEST123", v.getMatricula());
    }

    @Test
    void testFindAll() {
        ArrayList<Vehiculo> lista = vehiculoDAO.findall();
        assertNotNull(lista);
        assertTrue(lista.size() > 0);
    }

    @Test
    void testFindById() {
        Vehiculo v = vehiculoDAO.findByMatricula("TEST123");
        assertNotNull(v);

        Vehiculo encontrado = vehiculoDAO.findById(v.getIdVehiculo());
        assertNotNull(encontrado);
        assertEquals(v.getMatricula(), encontrado.getMatricula());
    }

    @Test
    void testDelete() {
        vehiculoDAO.delete("TEST123");

        Vehiculo eliminado = vehiculoDAO.findByMatricula("TEST123");
        assertNull(eliminado);
    }
}
