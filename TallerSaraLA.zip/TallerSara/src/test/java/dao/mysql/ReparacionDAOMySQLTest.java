package dao.mysql;

import entities.Estado;
import entities.Reparacion;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class ReparacionDAOMySQLTest {

    private ReparacionDAOMySQL reparacionDAO;

    @BeforeEach
    void setUp() {
        reparacionDAO = new ReparacionDAOMySQL();
    }

    @Test
    void testInsert() {
        Reparacion r = new Reparacion();
        r.setDescripcion("Cambio de aceite");
        r.setFechaEntrada(LocalDate.now());
        r.setCosteEstimado(120.50);
        r.setEstado(Estado.EN_CURSO);
        r.setVehiculo_id(1);   // ⚠️ Ajusta según tu BD
        r.setUsuario_id(1);    // ⚠️ Ajusta según tu BD

        reparacionDAO.insert(r);

        ArrayList<Reparacion> lista = reparacionDAO.findByVehiculoId(1, r);
        assertTrue(lista.stream().anyMatch(rep -> rep.getDescripcion().equals("Cambio de aceite")));
    }

    @Test
    void testUpdate() {
        Reparacion r = new Reparacion();
        r.setIdReparacion(1); // ⚠️ Ajusta según tu BD
        r.setDescripcion("Cambio de ruedas");
        r.setFechaEntrada(LocalDate.now());
        r.setCosteEstimado(300.0);
        r.setEstado(Estado.EN_CURSO);
        r.setVehiculo_id(1);
        r.setUsuario_id(1);

        reparacionDAO.update(r);

        ArrayList<Reparacion> lista = reparacionDAO.findByVehiculoId(1, r);
        assertTrue(lista.stream().anyMatch(rep -> rep.getDescripcion().equals("Cambio de ruedas")));
    }

    @Test
    void testUpdateEstado() {
        reparacionDAO.updateEstado(1, "FINALIZADA"); 

        ArrayList<Reparacion> lista = reparacionDAO.findFinalizadas();
        assertTrue(lista.stream().anyMatch(rep -> rep.getIdReparacion() == 1));
    }

    @Test
    void testFindFinalizadas() {
        ArrayList<Reparacion> lista = reparacionDAO.findFinalizadas();
        assertNotNull(lista);
        lista.forEach(r -> assertEquals(Estado.FINALIZADA, r.getEstado()));
    }

    @Test
    void testDelete() {
        reparacionDAO.delete(1); 

        ArrayList<Reparacion> lista = reparacionDAO.findFinalizadas();
        assertFalse(lista.stream().anyMatch(rep -> rep.getIdReparacion() == 1));
    }

    @Test
    void testFindByMatricula() {
        ArrayList<Reparacion> lista = reparacionDAO.findByMatricula("1234ABC"); 
        assertNotNull(lista);
    }

    @Test
    void testFindByMecanicoId() {
        Reparacion r = new Reparacion();
        r.setUsuario_id(1); 
        ArrayList<Reparacion> lista = reparacionDAO.findByMecanicoId(1, r);
        assertNotNull(lista);
    }
}
