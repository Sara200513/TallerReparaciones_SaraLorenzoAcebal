package dao.mysql;

import dao.DBConnection;
import entities.Cliente;
import org.junit.jupiter.api.*;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;

import static org.junit.jupiter.api.Assertions.*;

class ClienteDAOMySQLTest {

	private static Connection conexion;
	private ClienteDAOMySQL clienteDAO;

	@BeforeAll
	static void initConnection() {
		conexion = DBConnection.getInstance().getConnection();
	}

	@BeforeEach
	void setUp() {
		clienteDAO = new ClienteDAOMySQL();
	}

	@Test
	void testInsert() {
		Cliente c = new Cliente("12345678A", "Juan Pérez", "600123456", "juan@test.com");
		clienteDAO.insert(c);

		ArrayList<Cliente> clientes = clienteDAO.findAll();
		assertTrue(clientes.stream().anyMatch(cli -> cli.getDni().equals("12345678A")));
	}

	@Test
	void testUpdate() {
		Cliente c = new Cliente("12345678A", "Juan Actualizado", "611111111", "juan@update.com");
		c.setIdCliente(1); 
		clienteDAO.update(c);

		ArrayList<Cliente> clientes = clienteDAO.findAll();
		assertTrue(clientes.stream().anyMatch(cli -> cli.getNombre().equals("Juan Actualizado")));
	}

	@Test
	void testDelete() {
		clienteDAO.delete("12345678A");

		ArrayList<Cliente> clientes = clienteDAO.findAll();
		assertFalse(clientes.stream().anyMatch(cli -> cli.getDni().equals("12345678A")));
	}

	@Test
	void testFindAll() {
		ArrayList<Cliente> clientes = clienteDAO.findAll();
		assertNotNull(clientes);
		assertTrue(clientes.size() >= 0); 
	}

	@AfterAll
	static void closeConnection() throws SQLException {
		if (conexion != null && !conexion.isClosed()) {
			conexion.close();
		}
	}
}
