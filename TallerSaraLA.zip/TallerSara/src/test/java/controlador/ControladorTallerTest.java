package controlador;

import entities.Cliente;
import entities.Reparacion;
import entities.Usuario;
import entities.Vehiculo;
import entities.Estado;
import org.junit.jupiter.api.*;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class ControladorTallerTest {

    private ControladorTaller controlador;

    @BeforeEach
    void setUp() {
        controlador = ControladorTaller.getInstance();
    }

    @Test
    void testLoginYLogout() {
        Usuario u = controlador.login("11111111A", "1234"); // ⚠️ Ajusta credenciales válidas en tu BD
        assertNotNull(u);
        assertEquals("11111111A", u.getDni());

        controlador.logout();
        assertNull(controlador.login("fake", "fake"));
    }

    @Test
    void testListarReparacionesFinalizadas() {
        List<Reparacion> lista = controlador.listarReparacionesFinalizadas();
        assertNotNull(lista);
        lista.forEach(r -> assertEquals(Estado.FINALIZADA, r.getEstado()));
    }

    @Test
    void testInsertarClienteComoAdmin() {
        controlador.login("11111111A", "1234"); // ⚠️ Usuario administrador

        Cliente c = new Cliente("22222222B", "Pepe", "600123456", "pepe@test.com");
        boolean result = controlador.insertarCliente(c);

        assertTrue(result);

        Cliente encontrado = controlador.buscarClientePorDni("22222222B");
        assertNotNull(encontrado);
        assertEquals("Pepe", encontrado.getNombre());
    }

    @Test
    void testInsertarVehiculoComoAdmin() {
        controlador.login("11111111A", "1234"); // ⚠️ Usuario administrador

        Vehiculo v = new Vehiculo(0, "TEST123", "Toyota", "Corolla", 1); // cliente_id debe existir
        boolean result = controlador.insertarVehiculo(v);

        assertTrue(result);

        Vehiculo encontrado = controlador.buscarVehiculoPorMatricula("TEST123");
        assertNotNull(encontrado);
        assertEquals("Toyota", encontrado.getMarca());
    }

    @Test
    void testInsertarReparacionComoMecanico() {
        controlador.login("33333333C", "1234"); // ⚠️ Usuario mecánico

        Reparacion r = new Reparacion(0, 1, 0, "Cambio aceite", LocalDate.now(), 100.0, Estado.EN_CURSO);
        boolean result = controlador.insertarReparacion(r);

        assertTrue(result);

        ArrayList<Reparacion> lista = controlador.verReparacionesMecanico();
        assertTrue(lista.stream().anyMatch(rep -> rep.getDescripcion().equals("Cambio aceite")));
    }

    @Test
    void testActualizarEstadoReparacion() {
        controlador.login("33333333C", "1234"); // ⚠️ Usuario mecánico

        boolean result = controlador.actualizarEstadoReparacion(1, Estado.FINALIZADA); // ⚠️ Ajusta ID válido
        assertTrue(result);

        List<Reparacion> lista = controlador.listarReparacionesFinalizadas();
        assertTrue(lista.stream().anyMatch(r -> r.getIdReparacion() == 1));
    }
}

